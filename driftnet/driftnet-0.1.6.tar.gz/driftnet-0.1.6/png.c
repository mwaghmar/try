/*
 * png.c:
 *
 * Copyright (c) 2001 Chris Lightfoot. All rights reserved.
 * Email: chris@ex-parrot.com; WWW: http://www.ex-parrot.com/~chris/
 *
 */

static const char rcsid[] = "$Id: png.c,v 1.3 2002/06/10 21:25:48 chris Exp $";

