#include "../ck_cas.h"
#include "validate.h"
